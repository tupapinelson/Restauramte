
package Modelo;

public enum EstadoMesa {
    Libre,
    Reservada,
    Ocupada
}
