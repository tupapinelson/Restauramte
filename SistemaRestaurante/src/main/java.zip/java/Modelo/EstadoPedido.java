
package Modelo;

public enum EstadoPedido {
    Pendiente,
    Preparando,
    Listo,
    Completado,
    Cancelado
}
