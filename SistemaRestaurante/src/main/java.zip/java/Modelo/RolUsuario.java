
package Modelo;

public enum RolUsuario {
    Mesero,
    Cocinero,
    Gerente
}
